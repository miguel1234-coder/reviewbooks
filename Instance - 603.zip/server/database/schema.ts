export interface DatabaseSchema {
  users: {
    id: number;
    email: string;
    password_hash: string;
    is_admin: number; // SQLite stores booleans as integers
    subscription_status: 'active' | 'inactive' | 'expired';
    subscription_start_date: string | null;
    subscription_end_date: string | null;
    created_at: string;
  };
  books: {
    id: number;
    title: string;
    author: string;
    description: string | null;
    cover_image: string | null;
    category: string | null;
    rating: number;
    created_by: number | null;
    created_at: string;
  };
  payments: {
    id: number;
    user_id: number;
    amount: number;
    payment_date: string;
    status: string;
  };
  admin_files: {
    id: number;
    filename: string;
    original_name: string;
    file_path: string;
    uploaded_by: number;
    uploaded_at: string;
  };
}