import express from 'express';
import dotenv from 'dotenv';
import multer from 'multer';
import path from 'path';
import { setupStaticServing } from './static-serve.js';
import { db } from './database/connection.js';
import { sql } from 'kysely';
import { ensureUploadDir } from './utils/uploads.js';

dotenv.config();

const app = express();

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ensure upload directory exists
ensureUploadDir();

// File upload configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(process.env.DATA_DIRECTORY || './data', 'uploads');
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Auth middleware
const requireAuth = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const userId = req.headers['user-id'];
  if (!userId) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }
  
  try {
    const user = await db.selectFrom('users').selectAll().where('id', '=', Number(userId)).executeTakeFirst();
    if (!user) {
      res.status(401).json({ error: 'User not found' });
      return;
    }
    req.user = user;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(500).json({ error: 'Authentication failed' });
    return;
  }
};

const requireAdmin = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!req.user?.is_admin) {
    res.status(403).json({ error: 'Admin access required' });
    return;
  }
  next();
};

// Login endpoint
app.post('/api/login', async (req: express.Request, res: express.Response) => {
  const { email, password } = req.body;
  
  console.log('Login attempt:', { email });
  
  try {
    const user = await db.selectFrom('users').selectAll().where('email', '=', email).executeTakeFirst();
    
    if (!user || user.password_hash !== password) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }
    
    console.log('Login successful:', { userId: user.id, isAdmin: user.is_admin });
    res.json({ 
      user: { 
        id: user.id, 
        email: user.email, 
        is_admin: user.is_admin,
        subscription_status: user.subscription_status 
      } 
    });
    return;
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
    return;
  }
});

// Admin login with secret password
app.post('/api/admin-login', async (req: express.Request, res: express.Response) => {
  const { password } = req.body;
  
  console.log('Admin login attempt');
  
  if (password !== 'cacapedo') {
    res.status(401).json({ error: 'Invalid admin password' });
    return;
  }
  
  try {
    // Query using integer 1 instead of boolean true for SQLite compatibility
    const adminUser = await db.selectFrom('users').selectAll().where('is_admin', '=', 1).executeTakeFirst();
    
    if (!adminUser) {
      res.status(404).json({ error: 'Admin user not found' });
      return;
    }
    
    console.log('Admin login successful:', { userId: adminUser.id });
    res.json({ 
      user: { 
        id: adminUser.id, 
        email: adminUser.email, 
        is_admin: adminUser.is_admin,
        subscription_status: 'active'
      } 
    });
    return;
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ error: 'Admin login failed' });
    return;
  }
});

// Register endpoint
app.post('/api/register', async (req: express.Request, res: express.Response) => {
  const { email, password } = req.body;
  
  console.log('Registration attempt:', { email });
  
  try {
    const existingUser = await db.selectFrom('users').selectAll().where('email', '=', email).executeTakeFirst();
    
    if (existingUser) {
      res.status(400).json({ error: 'User already exists' });
      return;
    }
    
    const result = await db.insertInto('users')
      .values({ email, password_hash: password })
      .returningAll()
      .executeTakeFirst();
    
    console.log('Registration successful:', { userId: result?.id });
    res.json({ 
      user: { 
        id: result?.id, 
        email: result?.email, 
        is_admin: result?.is_admin,
        subscription_status: result?.subscription_status 
      } 
    });
    return;
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
    return;
  }
});

// Get books
app.get('/api/books', async (req: express.Request, res: express.Response) => {
  try {
    const books = await db.selectFrom('books').selectAll().execute();
    console.log('Retrieved books:', books.length);
    res.json({ books });
    return;
  } catch (error) {
    console.error('Error fetching books:', error);
    res.status(500).json({ error: 'Failed to fetch books' });
    return;
  }
});

// Add book (admin only)
app.post('/api/books', requireAuth, requireAdmin, async (req: express.Request, res: express.Response) => {
  const { title, author, description, category, rating } = req.body;
  
  console.log('Adding book:', { title, author });
  
  try {
    const result = await db.insertInto('books')
      .values({ 
        title, 
        author, 
        description, 
        category, 
        rating: rating || 0,
        created_by: req.user!.id 
      })
      .returningAll()
      .executeTakeFirst();
    
    console.log('Book added successfully:', result?.id);
    res.json({ book: result });
    return;
  } catch (error) {
    console.error('Error adding book:', error);
    res.status(500).json({ error: 'Failed to add book' });
    return;
  }
});

// Subscribe endpoint - now free for everyone
app.post('/api/subscribe', requireAuth, async (req: express.Request, res: express.Response) => {
  const userId = req.user!.id;
  
  console.log('Activating free access for user:', userId);
  
  try {
    // Activate free access for everyone
    await db.updateTable('users')
      .set({
        subscription_status: 'active',
        subscription_start_date: new Date().toISOString(),
        subscription_end_date: null // No expiration for free access
      })
      .where('id', '=', userId)
      .execute();
    
    console.log('Free access activated for user:', userId);
    
    if (req.user!.is_admin) {
      res.json({ message: 'Acceso de administrador confirmado' });
    } else {
      res.json({ message: 'Acceso gratuito activado exitosamente' });
    }
    return;
  } catch (error) {
    console.error('Activation error:', error);
    res.status(500).json({ error: 'Failed to activate access' });
    return;
  }
});

// Admin revenue dashboard - now tracks free activations instead of payments
app.get('/api/admin/revenue', requireAuth, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    const totalRevenue = await db.selectFrom('payments')
      .select((eb) => eb.fn.sum('amount').as('total'))
      .where('status', '=', 'completed')
      .executeTakeFirst();
    
    const monthlyRevenue = await db.selectFrom('payments')
      .select([
        sql<string>`strftime('%Y-%m', payment_date)`.as('month'),
        sql<number>`sum(amount)`.as('total')
      ])
      .where('status', '=', 'completed')
      .groupBy(sql`strftime('%Y-%m', payment_date)`)
      .execute();
    
    const activeUsers = await db.selectFrom('users')
      .select((eb) => eb.fn.count('id').as('count'))
      .where('subscription_status', '=', 'active')
      .executeTakeFirst();
    
    console.log('Admin dashboard data retrieved');
    res.json({
      totalRevenue: totalRevenue?.total || 0,
      monthlyRevenue,
      activeSubscriptions: activeUsers?.count || 0
    });
    return;
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
    return;
  }
});

// File upload endpoint (admin only)
app.post('/api/admin/upload', requireAuth, requireAdmin, upload.single('file'), async (req: express.Request, res: express.Response) => {
  if (!req.file) {
    res.status(400).json({ error: 'No file uploaded' });
    return;
  }
  
  console.log('File uploaded:', req.file.filename);
  
  try {
    const result = await db.insertInto('admin_files')
      .values({
        filename: req.file.filename,
        original_name: req.file.originalname,
        file_path: req.file.path,
        uploaded_by: req.user!.id
      })
      .returningAll()
      .executeTakeFirst();
    
    console.log('File record saved:', result?.id);
    res.json({ file: result });
    return;
  } catch (error) {
    console.error('Error saving file record:', error);
    res.status(500).json({ error: 'Failed to save file record' });
    return;
  }
});

// Get uploaded files (admin only)
app.get('/api/admin/files', requireAuth, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    const files = await db.selectFrom('admin_files').selectAll().execute();
    console.log('Retrieved admin files:', files.length);
    res.json({ files });
    return;
  } catch (error) {
    console.error('Error fetching files:', error);
    res.status(500).json({ error: 'Failed to fetch files' });
    return;
  }
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(process.env.DATA_DIRECTORY || './data', 'uploads')));

// Export a function to start the server
export async function startServer(port) {
  try {
    if (process.env.NODE_ENV === 'production') {
      setupStaticServing(app);
    }
    app.listen(port, () => {
      console.log(`API Server running on port ${port}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

// Start the server directly if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('Starting server...');
  startServer(process.env.PORT || 3001);
}

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        email: string;
        is_admin: boolean;
        subscription_status: string;
      };
    }
  }
}