import fs from 'fs';
import path from 'path';

export function ensureUploadDir() {
  const uploadDir = path.join(process.env.DATA_DIRECTORY || './data', 'uploads');
  
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
    console.log('Created uploads directory:', uploadDir);
  }
  
  return uploadDir;
}