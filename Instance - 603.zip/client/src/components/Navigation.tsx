import * as React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BookOpen, User, LogOut, Settings } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export function Navigation() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold">BookRecommends</span>
        </Link>

        <div className="flex items-center gap-4">
          <Link to="/books">
            <Button variant="ghost">Libros</Button>
          </Link>
          
          {!user && (
            <>
              <Link to="/subscribe">
                <Button variant="ghost">Acceso Gratuito</Button>
              </Link>
              <Link to="/login">
                <Button>Iniciar Sesión</Button>
              </Link>
            </>
          )}

          {user && (
            <>
              <Link to="/subscribe">
                <Button variant="ghost">Mi Acceso</Button>
              </Link>
              
              {user.is_admin && (
                <Link to="/admin">
                  <Button variant="ghost">
                    <Settings className="h-4 w-4 mr-2" />
                    Admin
                  </Button>
                </Link>
              )}
              
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span className="text-sm">{user.email}</span>
                <Button variant="ghost" size="sm" onClick={handleLogout}>
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}