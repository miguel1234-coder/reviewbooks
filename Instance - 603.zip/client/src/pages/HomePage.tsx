import * as React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Star, Users, Heart } from 'lucide-react';
import { Navigation } from '@/components/Navigation';

export function HomePage() {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center py-16">
          <h1 className="text-5xl font-bold mb-6">
            Descubre tu próxima gran lectura
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Únete a nuestra comunidad de lectores y accede a recomendaciones personalizadas de libros completamente gratis.
          </p>
          <div className="flex gap-4 justify-center">
            <Link to="/books">
              <Button size="lg">Ver Libros</Button>
            </Link>
            <Link to="/subscribe">
              <Button variant="outline" size="lg">Acceso Gratuito</Button>
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 py-16">
          <Card>
            <CardHeader>
              <BookOpen className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Recomendaciones Curadas</CardTitle>
              <CardDescription>
                Descubre libros seleccionados cuidadosamente por expertos en literatura.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Star className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Valoraciones Honestas</CardTitle>
              <CardDescription>
                Lee reseñas detalladas y valoraciones de otros lectores como tú.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Heart className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Completamente Gratis</CardTitle>
              <CardDescription>
                Acceso completo a todas las recomendaciones sin ningún costo.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center py-16 bg-muted rounded-lg">
          <h2 className="text-3xl font-bold mb-4">
            ¿Listo para encontrar tu próximo libro favorito?
          </h2>
          <p className="text-muted-foreground mb-8">
            Únete hoy y comienza tu aventura literaria sin costo alguno.
          </p>
          <Link to="/subscribe">
            <Button size="lg">Acceso Gratuito</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}