import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/context/AuthContext';
import { Navigation } from '@/components/Navigation';

export function LoginPage() {
  const [isLogin, setIsLogin] = React.useState(true);
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [adminPassword, setAdminPassword] = React.useState('');
  const [showAdminLogin, setShowAdminLogin] = React.useState(false);
  const [error, setError] = React.useState('');
  
  const { login, register, adminLogin, isLoading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    let success = false;
    if (showAdminLogin) {
      success = await adminLogin(adminPassword);
    } else if (isLogin) {
      success = await login(email, password);
    } else {
      success = await register(email, password);
    }

    if (success) {
      navigate('/');
    } else {
      setError('Error en las credenciales. Inténtalo de nuevo.');
    }
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>
              {showAdminLogin ? 'Acceso de Administrador' : isLogin ? 'Iniciar Sesión' : 'Registrarse'}
            </CardTitle>
            <CardDescription>
              {showAdminLogin ? 'Ingresa la contraseña secreta' : isLogin ? 'Accede a tu cuenta' : 'Crea una nueva cuenta'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {showAdminLogin ? (
                <div>
                  <Label htmlFor="adminPassword">Contraseña de Administrador</Label>
                  <Input
                    id="adminPassword"
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    required
                  />
                </div>
              ) : (
                <>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </>
              )}

              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Cargando...' : showAdminLogin ? 'Acceder como Admin' : isLogin ? 'Iniciar Sesión' : 'Registrarse'}
              </Button>
            </form>

            <div className="mt-4 space-y-2">
              {!showAdminLogin && (
                <Button
                  variant="ghost"
                  className="w-full"
                  onClick={() => setIsLogin(!isLogin)}
                >
                  {isLogin ? 'Crear cuenta nueva' : 'Ya tengo cuenta'}
                </Button>
              )}
              
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setShowAdminLogin(!showAdminLogin)}
              >
                {showAdminLogin ? 'Volver al login normal' : 'Acceso de Administrador'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}