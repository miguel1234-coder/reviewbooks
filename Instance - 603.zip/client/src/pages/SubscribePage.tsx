import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Heart } from 'lucide-react';
import { Navigation } from '@/components/Navigation';
import { useAuth } from '@/context/AuthContext';

export function SubscribePage() {
  const [isActivating, setIsActivating] = React.useState(false);
  const [message, setMessage] = React.useState('');
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleActivate = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    setIsActivating(true);
    setMessage('');

    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'user-id': user.id.toString(),
        },
      });

      if (response.ok) {
        const data = await response.json();
        setMessage(data.message);
        setTimeout(() => {
          navigate('/books');
        }, 2000);
      } else {
        setMessage('Error al activar el acceso. Inténtalo de nuevo.');
      }
    } catch (error) {
      console.error('Activation error:', error);
      setMessage('Error de conexión. Inténtalo de nuevo.');
    } finally {
      setIsActivating(false);
    }
  };

  const isAlreadyActive = user && (user.subscription_status === 'active' || user.is_admin);

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">Acceso Gratuito</h1>
          <p className="text-xl text-muted-foreground mb-8">
            Accede a todas nuestras recomendaciones de libros completamente gratis
          </p>

          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <div className="flex justify-center items-center mb-4">
                <Heart className="h-12 w-12 text-primary" />
              </div>
              <CardTitle>Plan Gratuito</CardTitle>
              <CardDescription>
                Acceso completo a todas las funcionalidades sin costo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {[
                  'Recomendaciones ilimitadas de libros',
                  'Valoraciones y reseñas detalladas',
                  'Categorías especializadas',
                  'Actualizaciones regulares',
                  'Acceso completo sin restricciones'
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>

              {message && (
                <div className="p-3 bg-green-100 text-green-800 rounded-md text-sm">
                  {message}
                </div>
              )}

              {isAlreadyActive ? (
                <div className="text-center">
                  <p className="text-green-600 font-medium mb-4">
                    {user?.is_admin ? '¡Acceso de administrador activo!' : '¡Ya tienes acceso completo!'}
                  </p>
                  <Button onClick={() => navigate('/books')} className="w-full">
                    Ver Libros
                  </Button>
                </div>
              ) : (
                <Button 
                  onClick={handleActivate} 
                  className="w-full" 
                  disabled={isActivating}
                >
                  {isActivating ? 'Activando...' : 'Activar Acceso Gratuito'}
                </Button>
              )}

              {!user && (
                <p className="text-sm text-muted-foreground text-center">
                  Necesitas <button 
                    onClick={() => navigate('/login')} 
                    className="text-primary hover:underline"
                  >
                    iniciar sesión
                  </button> para activar tu acceso
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}