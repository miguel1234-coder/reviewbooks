import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Navigation } from '@/components/Navigation';
import { useAuth } from '@/context/AuthContext';
import { DollarSign, Upload, BookOpen, FileText, Users } from 'lucide-react';

export function AdminPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [dashboardData, setDashboardData] = React.useState<any>(null);
  const [files, setFiles] = React.useState<any[]>([]);
  const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
  const [bookForm, setBookForm] = React.useState({
    title: '',
    author: '',
    description: '',
    category: '',
    rating: 0
  });
  const [loading, setLoading] = React.useState(false);
  const [message, setMessage] = React.useState('');

  React.useEffect(() => {
    if (!user?.is_admin) {
      navigate('/');
      return;
    }
    fetchDashboardData();
    fetchFiles();
  }, [user, navigate]);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api/admin/revenue', {
        headers: { 'user-id': user!.id.toString() }
      });
      if (response.ok) {
        const data = await response.json();
        setDashboardData(data);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

  const fetchFiles = async () => {
    try {
      const response = await fetch('/api/admin/files', {
        headers: { 'user-id': user!.id.toString() }
      });
      if (response.ok) {
        const data = await response.json();
        setFiles(data.files);
      }
    } catch (error) {
      console.error('Error fetching files:', error);
    }
  };

  const handleFileUpload = async () => {
    if (!selectedFile) return;

    setLoading(true);
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: { 'user-id': user!.id.toString() },
        body: formData
      });

      if (response.ok) {
        setMessage('Archivo subido exitosamente');
        setSelectedFile(null);
        fetchFiles();
      } else {
        setMessage('Error al subir archivo');
      }
    } catch (error) {
      console.error('Upload error:', error);
      setMessage('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  const handleAddBook = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/books', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'user-id': user!.id.toString()
        },
        body: JSON.stringify(bookForm)
      });

      if (response.ok) {
        setMessage('Libro agregado exitosamente');
        setBookForm({ title: '', author: '', description: '', category: '', rating: 0 });
      } else {
        setMessage('Error al agregar libro');
      }
    } catch (error) {
      console.error('Add book error:', error);
      setMessage('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  if (!user?.is_admin) {
    return null;
  }

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Panel de Administrador</h1>

        {message && (
          <div className="mb-4 p-3 bg-green-100 text-green-800 rounded-md">
            {message}
          </div>
        )}

        {/* Dashboard Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <DollarSign className="h-8 w-8 text-green-600 mb-2" />
              <CardTitle>Ingresos Históricos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                ${dashboardData?.totalRevenue || 0}
              </p>
              <p className="text-sm text-muted-foreground">
                (Ahora la plataforma es gratuita)
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Users className="h-8 w-8 text-blue-600 mb-2" />
              <CardTitle>Usuarios Activos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {dashboardData?.activeSubscriptions || 0}
              </p>
              <p className="text-sm text-muted-foreground">
                Con acceso gratuito
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <FileText className="h-8 w-8 text-purple-600 mb-2" />
              <CardTitle>Archivos Subidos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {files.length}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Add Book Form */}
          <Card>
            <CardHeader>
              <CardTitle>Agregar Nuevo Libro</CardTitle>
              <CardDescription>
                Añade una nueva recomendación de libro
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddBook} className="space-y-4">
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={bookForm.title}
                    onChange={(e) => setBookForm({ ...bookForm, title: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="author">Autor</Label>
                  <Input
                    id="author"
                    value={bookForm.author}
                    onChange={(e) => setBookForm({ ...bookForm, author: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descripción</Label>
                  <Input
                    id="description"
                    value={bookForm.description}
                    onChange={(e) => setBookForm({ ...bookForm, description: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="category">Categoría</Label>
                  <Input
                    id="category"
                    value={bookForm.category}
                    onChange={(e) => setBookForm({ ...bookForm, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="rating">Valoración (0-5)</Label>
                  <Input
                    id="rating"
                    type="number"
                    min="0"
                    max="5"
                    step="0.1"
                    value={bookForm.rating}
                    onChange={(e) => setBookForm({ ...bookForm, rating: parseFloat(e.target.value) })}
                  />
                </div>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Agregando...' : 'Agregar Libro'}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* File Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Subir Archivos</CardTitle>
              <CardDescription>
                Sube archivos a la plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="file">Seleccionar Archivo</Label>
                <Input
                  id="file"
                  type="file"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                />
              </div>
              <Button 
                onClick={handleFileUpload} 
                disabled={!selectedFile || loading}
                className="w-full"
              >
                <Upload className="h-4 w-4 mr-2" />
                {loading ? 'Subiendo...' : 'Subir Archivo'}
              </Button>

              {files.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Archivos Subidos:</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {files.map((file) => (
                      <div key={file.id} className="text-sm p-2 bg-muted rounded">
                        <p className="font-medium">{file.original_name}</p>
                        <p className="text-muted-foreground text-xs">
                          {new Date(file.uploaded_at).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Monthly Revenue Table - kept for historical data */}
        {dashboardData?.monthlyRevenue && dashboardData.monthlyRevenue.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Ingresos Históricos por Mes</CardTitle>
              <CardDescription>
                Datos históricos de cuando la plataforma tenía suscripción
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mes</TableHead>
                    <TableHead>Ingresos</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dashboardData.monthlyRevenue.map((month: any, index: number) => (
                    <TableRow key={index}>
                      <TableCell>{month.month}</TableCell>
                      <TableCell>${month.total}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}